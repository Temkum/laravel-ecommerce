<div>
  <style>
    nav svg {
      height: 20px;
    }

    nav .hidden {
      display: block !important;
    }

    .add-new {
      float: right;
    }

    .text-lg {
      font-size: 2.5rem;
    }

  </style>

  <div class="container mt">
    <div class="row">
      <div class="col-md-12">
        <div class="panel panel-default">
          <div class="panel-heading heading-1">
            <div class="row">
              <div class="col-md-6 text-uppercase text-lg">
                All products
              </div>
              <div class="col-md-6 add-new">
                <a href="<?php echo e(route('admin.add-product')); ?>" class="btn btn-primary pull-right">Add New Product</a>
              </div>
            </div>
          </div>

          <div class="panel-body">
            <?php if(Session::has('message')): ?>
              <div class="alert alert-success" role="alert">
                <?php echo e(Session::get('message')); ?>

              </div>
            <?php endif; ?>
            <table class="table table-striped">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Image</th>
                  <th>Name</th>
                  <th>Stock</th>
                  <th>Price</th>
                  <th>Sale price</th>
                  <th>Category</th>
                  <th>Date</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($product->id); ?></td>
                    <td><img src="<?php echo e(asset('assets/images/products')); ?>/<?php echo e($product->image); ?>"
                        alt="<?php echo e($product->name); ?>" width="60"></td>
                    <td><?php echo e($product->name); ?></td>
                    <td><?php echo e($product->stock_status); ?></td>
                    <td><?php echo e($product->regular_price); ?></td>
                    <td><?php echo e($product->sale_price); ?></td>
                    <td><?php echo e($product->category->name); ?></td>
                    <td><?php echo e($product->created_at); ?></td>
                    <td>
                      <a href="<?php echo e(route('admin.edit-product', ['product_slug' => $product->slug])); ?>"><i
                          class="fa fa-edit fa-2x text-purple-100"></i>
                      </a>
                      <a href="<?php echo e(route('admin.edit-product', ['product_slug' => $product->slug])); ?>"><i
                          class="fa fa-trash fa-2x text-danger" style="margin-left: 1.8rem;"
                          onclick="confirm('Sure you want to delete this product?') || event.stopImmediatePropagation()"
                          wire:click.prevent="deleteProduct(<?php echo e($product->id); ?>)"></i>
                      </a>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>

            
            <?php echo e($products->links()); ?>

          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php /**PATH /opt/lampp/htdocs/laravel-ecommerce/resources/views/livewire/admin/admin-product-component.blade.php ENDPATH**/ ?>