<div>
  <style>
    .container {
      padding: 40px 0;
    }

    .slider-h {
      font-size: 1.8rem;
    }

    .add-new {
      float: right;
    }

    .ml {
      margin-left: 5px;
    }

  </style>

  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="panel panel-default">
          <div class="panel-heading">
            <div class="row">
              <div class="col-md-6 slider-h">
                All SLIDES
              </div>
              <div class="col-md-6 add-new">
                <a href="<?php echo e(route('admin.addhomeslider')); ?>" class="btn btn-primary">Add New Slides</a>
              </div>
            </div>
          </div>

          <div class="panel-body">
            <?php if(Session::has('message')): ?>
              <div class="alert alert-success" role="alert"><?php echo e(Session::get('message')); ?></div>
            <?php endif; ?>
            <table class="table table-striped">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Image</th>
                  <th>Title</th>
                  <th>Subtitle</th>
                  <th>Price</th>
                  <th>Link</th>
                  <th>Status</th>
                  <th>Date</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php if($sliders->count() > 0): ?>
                  <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($slider->id); ?></td>
                      <td><img src="<?php echo e(asset('assets/images/sliders')); ?>/<?php echo e($slider->image); ?>" width="120" />
                      </td>
                      <td><?php echo e($slider->title); ?></td>
                      <td><?php echo e($slider->subtitle); ?></td>
                      <td><?php echo e($slider->price); ?></td>
                      <td><?php echo e($slider->link); ?></td>
                      <td><?php echo e($slider->status == 1 ? 'Active' : 'Inactive'); ?></td>
                      <td><?php echo e($slider->created_at); ?></td>
                      <td>
                        <a href="<?php echo e(route('admin.edithomeslider', ['slide_id' => $slider->id])); ?>"><i
                            class="fa fa-edit fa-2x text-info mr-5"></i>
                        </a>
                        <a href="#"
                          onclick="confirm('Are you sure you want to delete this category?') || event.stopImmediatePropagation()"
                          wire:click.prevent="deleteSlide(<?php echo e($slider->id); ?>)"><i
                            class="fa fa-trash fa-2x text-danger"></i>
                        </a>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            <?php else: ?>
              <p class="no-products">No slides available!</p>
              <?php endif; ?>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php /**PATH /opt/lampp/htdocs/laravel-ecommerce/resources/views/livewire/admin/admin-home-slider-component.blade.php ENDPATH**/ ?>