<div>
  <h1>USER/CUSTOMER DASHBOARD</h1>
</div>
<?php /**PATH /opt/lampp/htdocs/laravel-ecommerce/resources/views/livewire/user/user-dashboard-component.blade.php ENDPATH**/ ?>