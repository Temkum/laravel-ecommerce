<div>
  <div class="container" style="padding: 40px 0;">
    <div class="row">
      <div class="col-md-12">
        <div class="panel panel-default">
          <div class="panel-heading">
            <div class="row">
              <div class="col-md-6">
                <a href="<?php echo e(route('admin.products')); ?>" class="btn btn-primary pull-left">ALL PRODUCTS</a>
              </div>
              <div class="col-md-6 text-lg">
                EDIT PRODUCT
              </div>
            </div>
          </div>

          <div class="panel-body">
            <?php if(Session::has('message')): ?>
              <div class="alert alert-success" role="alert"><?php echo e(Session::get('message')); ?></div>
            <?php endif; ?>
            <form action="" class="form-horizontal" enctype="multipart/form-data" wire:submit.prevent="updateProduct">
              <div class="form-group">
                <label for="" class="col-md-4 control-label">Product Name</label>
                <div class="col-md-4">
                  <input type="text" name="" id="" placeholder="Product Name" class="form-control input-md"
                    wire:model="name" wire:keyup="generateSlug">
                  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>

              <div class="form-group">
                <label for="" class="col-md-4 control-label">Product Slug</label>
                <div class="col-md-4">
                  <input type="text" name="" id="" placeholder="Product Slug" class="form-control input-md"
                    wire:model="slug">
                </div>
                <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <p class="text-danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

              <div class="form-group">
                <label for="" class="col-md-4 control-label">Short Description</label>
                <div class="col-md-4" wire:ignore>
                  <textarea name="" id="short-description" placeholder="Short Description" class="form-control input-md"
                    wire:model="short_description"></textarea>
                  <?php $__errorArgs = ['short_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>

              <div class="form-group">
                <label for="" class="col-md-4 control-label">Description</label>
                <div class="col-md-4" wire:ignore>
                  <textarea rows="10" cols="30" placeholder="Description" class="form-control input-md" id="description"
                    wire:model="description"></textarea>
                  <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>

              <div class="form-group">
                <label for="" class="col-md-4 control-label">Regular Price</label>
                <div class="col-md-4">
                  <input type="number" name="" id="" placeholder="Regular price" class="form-control input-md"
                    wire:model="regular_price">
                  <?php $__errorArgs = ['regular_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>

              <div class="form-group">
                <label for="" class="col-md-4 control-label">Sale Price</label>
                <div class="col-md-4">
                  <input type="number" name="" id="" placeholder="Sale price" class="form-control input-md"
                    wire:model="sale_price">
                  <?php $__errorArgs = ['sale_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>

              <div class="form-group">
                <label for="" class="col-md-4 control-label">SKU</label>
                <div class="col-md-4">
                  <input type="text" name="" id="" placeholder="SKU" class="form-control input-md" wire:model="SKU">
                  <?php $__errorArgs = ['SKU'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>

              <div class="form-group">
                <label for="" class="col-md-4 control-label">Stock</label>
                <div class="col-md-4">
                  <select name="" id="" class="form-control" wire:model="stock_status">
                    <option value="in_stock">In stock</option>
                    <option value="out-of-stock">Out of stock</option>
                  </select>
                  <?php $__errorArgs = ['stock_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>

              <div class="form-group">
                <label for="" class="col-md-4 control-label">Feature</label>
                <div class="col-md-4">
                  <select name="" id="" class="form-control" wire:model="featured">
                    <option value="0">No</option>
                    <option value="1">Yes</option>
                  </select>
                  <?php $__errorArgs = ['featured'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>

              <div class="form-group">
                <label for="" class="col-md-4 control-label">Quantity</label>
                <div class="col-md-4">
                  <input type="number" name="" id="" placeholder="Quantity" class="form-control input-md"
                    wire:model="quantity">
                  <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>

              <div class="form-group">
                <label for="" class="col-md-4 control-label">Product Image</label>
                <div class="col-md-4">
                  <input type="file" name="" id="" class="input-file" wire:model="new_image">
                  <?php if($new_image): ?>
                    <img src="<?php echo e($new_image->temporaryUrl()); ?>" width="120" />
                  <?php else: ?>
                    <img src="<?php echo e(asset('assets/images/products')); ?>/<?php echo e($image); ?>" width="120" />
                  <?php endif; ?>
                  
                </div>
              </div>

              <div class="form-group">
                <label for="" class="col-md-4 control-label">Product Gallery</label>
                <div class="col-md-4">
                  <input type="file" name="" id="" class="input-file" wire:model="new_images" multiple>
                  <?php if($new_images): ?>
                    <?php $__currentLoopData = $new_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new_image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <img src="<?php echo e($new_image->temporaryUrl()); ?>" width="120" />
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($image): ?>
                        <img src="<?php echo e(asset('assets/images/products')); ?>/<?php echo e($image); ?>" width="120" />
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                  <?php $__errorArgs = ['new_images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>

              <div class="form-group">
                <label for="" class="col-md-4 control-label">Category</label>
                <div class="col-md-4">
                  <select name="" id="" class="form-control" wire:model="category_id">
                    <option value="0">Select Category</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger"><?php echo e($message); ?></p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>

              <div class="form-group">
                <label for="" class="col-md-4 control-label"></label>
                <div class="col-md-4">
                  <button type="submit" class="btn btn-primary">Update</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->startPush('scripts'); ?>
  <script>
    $(function() {
      tinymce.init({
        selector: '#short-description',
        setup: function(editor) {
          editor.on('Change', function(e) {
            tinyMCE.triggerSave();
            let sd_data = $('#short-description').val();
            window.livewire.find('<?php echo e($_instance->id); ?>').set('short_description', sd_data);
          })
        }
      })

      tinymce.init({
        selector: '#description',
        setup: function(editor) {
          editor.on('Change', function(e) {
            tinyMCE.triggerSave();
            let desc_data = $('#description').val();
            window.livewire.find('<?php echo e($_instance->id); ?>').set('description', desc_data);
          })
        }
      })

    });
  </script>
<?php $__env->stopPush(); ?>
<?php /**PATH /opt/lampp/htdocs/laravel-ecommerce/resources/views/livewire/admin/admin-edit-product-component.blade.php ENDPATH**/ ?>