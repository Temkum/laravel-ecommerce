<div>
  <style>
    .container {
      padding: 30px 0;
    }

    .slider-h {
      font-size: 1.8rem;
      text-transform: uppercase;
    }

    .add-new {
      float: left;
    }

  </style>

  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="panel panel-default">
          <div class="panel-heading">
            <div class="row">
              <div class="col-md-6">
                <a href="<?php echo e(route('admin.homeslider')); ?>" class="btn btn-primary">Back to slides</a>
              </div>
              <div class="col-md-6 slider-h">
                Add Slide
              </div>
            </div>
          </div>

          <div class="panel-body">
            <?php if(Session::has('message')): ?>
              <div class="alert alert-success" role="alert"><?php echo e(Session::get('message')); ?></div>
            <?php endif; ?>
            <form action="" class="form-horizontal" enctype="multipart/form-data" wire:submit.prevent="addSlide">
              <div class="form-group">
                <label for="" class="col-md-4 control-label">Title</label>
                <div class="col-md-4">
                  <input type="text" placeholder="Title" class="form-control input-md" wire:model="title">
                </div>
              </div>

              <div class="form-group">
                <label for="" class="col-md-4 control-label">Subtitle</label>
                <div class="col-md-4">
                  <input type="text" placeholder="Subtitle" class="form-control input-md" wire:model="subtitle">
                </div>
              </div>

              <div class="form-group">
                <label for="" class="col-md-4 control-label">Price</label>
                <div class="col-md-4">
                  <input type="number" placeholder="Price" class="form-control input-md" wire:model="price">
                </div>
              </div>

              <div class="form-group">
                <label for="" class="col-md-4 control-label">Link</label>
                <div class="col-md-4">
                  <input type="text" placeholder="Link" class="form-control input-md" wire:model="link">
                </div>
              </div>

              <div class="form-group">
                <label for="" class="col-md-4 control-label">Status</label>
                <div class="col-md-4">
                  <select name="" id="" wire:model="status">
                    <option value="1">Active</option>
                    <option value="0">Inactive</option>
                  </select>
                </div>
              </div>

              <div class="form-group">
                <label for="" class="col-md-4 control-label">Image</label>
                <div class="col-md-4">
                  <input type="file" placeholder="Image" class="input-file" wire:model="image">
                  <?php if($image): ?>
                    <img src="<?php echo e($image->temporaryUrl()); ?>" width="120" />
                  <?php endif; ?>
                </div>
              </div>

              <div class="form-group">
                <label for="" class="col-md-4 control-label"></label>
                <div class="col-md-4">
                  <button type="submit" class="btn btn-success">Submit</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php /**PATH /opt/lampp/htdocs/laravel-ecommerce/resources/views/livewire/admin/admin-add-home-slider-component.blade.php ENDPATH**/ ?>