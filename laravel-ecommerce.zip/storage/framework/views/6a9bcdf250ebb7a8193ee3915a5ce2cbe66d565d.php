<div>
  <style>
    .add-new {
      float: right;
    }

    .text-lg {
      font-size: 2.5rem;
      text-transform: uppercase;
      font-weight: bold;
    }

    nav svg {
      height: 20px;
    }

    nav .hidden {
      display: block !important;
    }

  </style>

  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="panel panel-default">
          <div class="panel-heading text-lg">
            Orders
          </div>
          <div class="panel-body">
            <table class="table table-striped">
              <thead>
                <tr>
                  <th>Order ID</th>
                  <th>Subtotal</th>
                  <th>Discount</th>
                  <th>Tax</th>
                  <th>Total</th>
                  <th>First Name</th>
                  <th>Last Name</th>
                  <th>Mobile</th>
                  <th>Email</th>
                  <th>Zipcode</th>
                  <th>Status</th>
                  <th>Order Date</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($order->id); ?></td>
                    <td>$<?php echo e($order->subtotal); ?></td>
                    <td>$<?php echo e($order->discount); ?></td>
                    <td>$<?php echo e($order->tax); ?></td>
                    <td>$<?php echo e($order->total); ?></td>
                    <td><?php echo e($order->first_name); ?></td>
                    <td><?php echo e($order->last_name); ?></td>
                    <td><?php echo e($order->mobile); ?></td>
                    <td><?php echo e($order->email); ?></td>
                    <td><?php echo e($order->zip_code); ?></td>
                    <td><?php echo e($order->status); ?></td>
                    <td><?php echo e($order->created_at); ?></td>
                    <td><a href="<?php echo e(route('user.orderdetails', ['order_id' => $order->id])); ?>"
                        class="btn btn-small btn-info"><i class="fa fa-eye"></i></a></td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
            <?php echo e($orders->links()); ?>

          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php /**PATH /opt/lampp/htdocs/laravel-ecommerce/resources/views/livewire/user/user-orders.blade.php ENDPATH**/ ?>